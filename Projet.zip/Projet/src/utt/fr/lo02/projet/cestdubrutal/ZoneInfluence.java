package utt.fr.lo02.projet.cestdubrutal;

import java.util.*;

public class ZoneInfluence {
	protected String nom;
	protected boolean combatStatut;
	protected LinkedList<Combattant> combattantsJ1;
	protected LinkedList<Combattant> combattantsJ2;
	protected int id;
  
	public ZoneInfluence(String nom, int id)
	{
		this.nom=nom;
	  	this.combatStatut=false;
	  	this.combattantsJ1 = new LinkedList<Combattant>();
	  	this.combattantsJ2 = new LinkedList<Combattant>();
	  	this.id=id;
	}
	
	public void combattantsDansZone()
	{
		// Nom de la zone
		System.out.println("****** ZONE : "+ this.nom + " ******");
			
		// Affichage des combattants du joueur 1
		
		Iterator<Combattant> i1 = this.combattantsJ1.iterator();
		System.out.println("\nCombattants du joueur 1 : \n");
		while(i1.hasNext())
		{
			Combattant j1 = i1.next();
			System.out.println("ID :" +j1.id +" | Constitution : " +j1.constitution +" | Force :" +j1.force+ " | Resistance : " + j1.resistance + " | Initiative : " +j1.initiative + " | Dexterite : " + j1.dexterite + " | Reserviste : " +j1.reserviste + " | Deploiement : " + j1.deploiement);
		}
		
		// Affichage des combattants du joueur 2
		Iterator<Combattant> i2 = this.combattantsJ2.iterator();

		System.out.println("\nCombattants du joueur 2 : \n");
		while(i2.hasNext())
		{
			Combattant j2 = i2.next();
			System.out.println("ID :" +j2.id +" | Constitution : " +j2.constitution +" | Force :" +j2.force+ " | Resistance : " + j2.resistance + " | Initiative : " +j2.initiative + " | Dexterite" + j2.dexterite + " | Reserviste : " +j2.reserviste + " | Deploiement : "+ j2.deploiement);
		}
		
		System.out.println("\n*********************************************************************\n");
	}
}
