package utt.fr.lo02.projet.cestdubrutal;

public class Etudiant extends Combattant{
	public Etudiant(int id, String joueurPropriétaire) {
		this.creditsECTS = 30;
		this.dexterite = 0;
		this.force = 0;
		this.resistance = 0;
		this.constitution = 0;
		this.initiative = 0;
		Strategie strategie = new StrategieAleatoire();
		this.strategie = strategie;
		this.id = id;
		this.joueurPropriétaire = joueurPropriétaire;
		this.role = "Etudiant";
		this.reserviste = false;
		this.deploiement = false;
	}
	
	public boolean combattantVerifierIntegrite() {
		if (force>=0 & force <=10 & dexterite>=0 & dexterite<=10 & resistance>=0 & resistance<=10 & constitution>=0 & constitution<=30 & initiative>=0 & initiative<=10) {
			return true;
		}
		else {
			return false;
		}		
	}
}