package utt.fr.lo02.projet.cestdubrutal;

import java.util.*;

public class Partie {
	private HashSet<Joueur> joueurs;
	private HashSet<ZoneInfluence> zones;
	private static Partie instance = null;

	private Partie() {
		this.joueurs= new HashSet<Joueur>();
		this.zones= new HashSet<ZoneInfluence>();
		
		// Création des zones d'influence
		ZoneInfluence bibliotheque = new ZoneInfluence("Bibliotheque",1);
		ZoneInfluence bde = new ZoneInfluence("BDE",2);
		ZoneInfluence quartierAdministratif = new ZoneInfluence("Quartier Administratif",3);
		ZoneInfluence hallesIndustrielles = new ZoneInfluence("Halles Industrielles",4);
		ZoneInfluence halleSportive = new ZoneInfluence("Halle Sportive",5);
		
		// Ajout des zones d'influence dans la partie
		this.zones.add(bibliotheque);
		this.zones.add(bde);
		this.zones.add(quartierAdministratif);
		this.zones.add(hallesIndustrielles);
		this.zones.add(halleSportive);
		
		// Création des joueurs
		
		Joueur j1 = new Joueur("Julian", 1);
		Joueur j2 = new Joueur("Basset", 2);
		
		// Ajout des joueurs dans la partie
		
		this.joueurs.add(j1);
		this.joueurs.add(j2);
	}

	public static Partie getInstance() {
		if ( instance == null ) {
			instance = new Partie();
		}
		return instance;
	}
	
	
	
	public ZoneInfluence getZone()
	{
		Scanner clavier = new Scanner(System.in);
		System.out.println("Dans quelle zone voulez vous deployer/retirer un combattant \n1: Bibliotheque\n2: BDE\n3: Quartier Administratif\n4: Halles Industrielles \n5: Halle Sportive");
		
		int no_zone = clavier.nextInt();
		ZoneInfluence Z = this.zones.stream().filter(z -> z.id == no_zone).findFirst().orElse(null);
		
		return Z;
		
	}
	
	public void parametrerTroupes()
	{
		Scanner clavier = new Scanner(System.in);
		
		Iterator<Joueur> i= this.joueurs.iterator();
		while(i.hasNext())
		{
			Joueur j = i.next();
			System.out.println("\n" + j.getNom() + " choisit\n");
			int choix = 0;
			while(choix !=6)
			{
				System.out.println("Choisissez une opération\n1: Ajouter ou retirer des points a un combattant\n2: Modifier la strategie d un combattant\n3: Ajouter un reserviste \n4: Supprimer un reserviste\n5: Voir le solde de points \n6: Passer a l'etape suivante");
				choix = clavier.nextInt();
				System.out.println("\n" + j.getNom() + " choisit\n");
				switch(choix)
				{
				case 1:
					j.combattantModifierPoints(); // Fait
					break;
					
				case 2:
					j.combattantModifierStrategie();
					break;
					
				case 3:
					j.combattantMettreEnReserve(); // Fait
					break;
					
				case 4:
					j.combattantSortirReserve(); // Fait
					break;
					
				case 5:
					System.out.println("Il vous reste "+ j.getSoldePoints() + " points.");
					break;
					
				case 6:
					int nb_reservistes=j.getReservistesLength();
					int nb_titulaires=j.getTitulairesLength();
					
					if(nb_reservistes !=5 && nb_titulaires !=15)
					{
						choix=0;
					}
					
					break;
				default:
					System.out.println("Veuillez choisir une action existante !");
					break;		
				}
				
			}
		}	
	}
	
	
	
	
	public void deployerTroupes()
	{
		Scanner clavier = new Scanner(System.in);

		Iterator<Joueur> i= this.joueurs.iterator();
		while(i.hasNext())
		{
			Joueur j = i.next();
			System.out.println("Le joueur " + j.getNom() + " prepare sa tactique");
			
			int choix = 0;
			while(choix !=3)
			{
				System.out.println("Choisissez une opération\n1: Deployer un combattant dans une zone \n2: Retirer un combattant d une zone\n3: Passer a l'etape suivante");
				choix = clavier.nextInt();
				
				
				
				
				switch(choix)
				{
				
				// Deploiement d'un combattant
				case 1:
					System.out.println("\n>" + j.getNom() + " deploie un combattant\n");
					Combattant deploye = j.titulaireFindById();
					ZoneInfluence zone_deploiement = this.getZone();
					if(j.getId()==1 && deploye.deploiement==false)
					{
						deploye.deploiement=true;
						zone_deploiement.combattantsJ1.add(deploye);
						
						System.out.println(">Le combattant " + deploye.id + " de type " + deploye.role + " a ete deploye dans la zone " + zone_deploiement.nom + "\n");
					}
					else if (j.getId()==2 && deploye.deploiement==false) {
						deploye.deploiement=true;
						zone_deploiement.combattantsJ2.add(deploye);
						
						System.out.println(">Le combattant " + deploye.id + " de type " + deploye.role + " a ete deploye dans la zone " + zone_deploiement.nom + "\n");
					}
					else
					{
						System.out.println(">Le combattant est deja deploye" + "\n");
					}
					
					zone_deploiement.combattantsDansZone();
					
					break;
					
				// Retrait d'un combattant
				case 2:
					System.out.println("\n>" + j.getNom() + " retire un combattant\n");
					Combattant retire = j.titulaireFindById();
					ZoneInfluence zone_retrait = this.getZone();
					
					if(j.getId()==1 && zone_retrait.combattantsJ1.contains(retire))
					{
						retire.deploiement=false;
						zone_retrait.combattantsJ1.remove(retire);
						
						System.out.println(">Le combattant " + retire.id + " de type " + retire.role + " a ete retire de la zone " + zone_retrait.nom + "\n");
						
					}
					else if (j.getId()==2 && zone_retrait.combattantsJ2.contains(retire)) {
						retire.deploiement=false;
						zone_retrait.combattantsJ2.remove(retire);
						
						System.out.println(">Le combattant " + retire.id + " de type " + retire.role + " a ete retire de la zone " + zone_retrait.nom + "\n");
					}
					
					zone_retrait.combattantsDansZone();
					
					break;
				
				// Validation des deploiements
				case 3:
					
					boolean validite = this.verifierValidite(j);
					if(validite==false)
					{
						choix=0;
					}
					break;
					
				default:
					
					break;
				}
			}
		}
	}
	
	public boolean verifierValidite(Joueur j)
	{
		boolean validite = true;
		int joueur_id = j.getId();
		
		Iterator<ZoneInfluence> i = this.zones.iterator();
		while (i.hasNext())
		{
			ZoneInfluence z = i.next();
			
			switch(joueur_id)
			{
			case 1:
				if(z.combattantsJ1.size()<1)
				{
					validite = false;
					System.out.println(">Le joueur 1 " + j.getNom() + " n a pas deploye de combattant dans la zone : " + z.nom);
				}
				System.out.println("\n");
				break;
				
			case 2:
				if(z.combattantsJ2.size()<1)
				{
					validite = false;
					System.out.println(">Le joueur 2 " + j.getNom() + " n a pas deploye de combattant dans la zone : " + z.nom);
				}
				System.out.println("\n");
				break;
				
			default:
				break;
			}
		}
		
		return validite;
	}
	
	public void genererSetupParametrage()
	{
		Iterator<Joueur> i = this.joueurs.iterator();
		while(i.hasNext())
		{
			Joueur j = i.next();
			j.genererArmee();	
		}
	}
	
	public void genererSetupDeploiement()
	{
		Iterator<Joueur> i = this.joueurs.iterator();
		
		ZoneInfluence Bibliotheque = getZoneByID(1);
		ZoneInfluence BDE = getZoneByID(2);
		ZoneInfluence QuartierAdmin = getZoneByID(3);
		ZoneInfluence HallesIndus = getZoneByID(4);
		ZoneInfluence HalleSportive = getZoneByID(5);
		
		while(i.hasNext())
		{
			Joueur j = i.next();
			for (int k=1;k<16;k++)
			{
				Combattant C = j.findCombattantById(k);
				C.deploiement=true;
				if(k>=1 && k<=3)
				{
					
					if(j.getId()==1)
					{
						Bibliotheque.combattantsJ1.add(C);
					}
					else if(j.getId()==2)
					{
						Bibliotheque.combattantsJ2.add(C);
					}
				}
				
				if(k>=4 && k<=6)
				{
					if(j.getId()==1)
					{
						BDE.combattantsJ1.add(C);
					}
					else if(j.getId()==2)
					{
						BDE.combattantsJ2.add(C);
					}
					
				}
				
				if(k>=7 && k<=9)
				{
					
					if(j.getId()==1)
					{
						QuartierAdmin.combattantsJ1.add(C);
					}
					else if(j.getId()==2)
					{
						QuartierAdmin.combattantsJ2.add(C);
					}
					
				}
				
				if(k>=10 && k<=12)
				{
					
					if(j.getId()==1)
					{
						HallesIndus.combattantsJ1.add(C);
					}
					else if(j.getId()==2)
					{
						HallesIndus.combattantsJ2.add(C);
					}
				}
				
				if(k>=13 && k<=15)
				{
				
					if(j.getId()==1)
					{
						HalleSportive.combattantsJ1.add(C);
					}
					else if(j.getId()==2)
					{
						HalleSportive.combattantsJ2.add(C);
					}
				}
			}
			
			
		}
		
		Bibliotheque.combattantsDansZone();
		BDE.combattantsDansZone();
		QuartierAdmin.combattantsDansZone();
		HallesIndus.combattantsDansZone();
		HalleSportive.combattantsDansZone();
	}
	
	public ZoneInfluence getZoneByID(int no_zone)
	{
		ZoneInfluence Z = this.zones.stream().filter(z -> z.id == no_zone).findFirst().orElse(null);
		return Z;
	}
	
	
	public static void main (String[] args)
	{
		Partie partie = Partie.getInstance();
		System.out.println(partie);
		
		//partie.parametrerTroupes();
		partie.genererSetupParametrage();
		
		// partie.deployerTroupes();
		partie.genererSetupDeploiement();
		
	}
	
}
