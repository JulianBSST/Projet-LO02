package utt.fr.lo02.projet.cestdubrutal;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Joueur {
		private int id;
		private String nom;
		private Programmes programme;
		private LinkedList<Combattant> armeeEtudiants;
		private List<Combattant> reservistes;
		private List<Combattant> titulaires;
		private LinkedList<ZoneInfluence> zonesControlees;
		private int soldePoints;
		
		
		// Constructeur du joueur

		public Joueur(String nom, int id) {
			this.nom=nom;
			this.id=id;

			// Choix du programme
			int choix = 0;
			Scanner entreeClavier = new Scanner(System.in);
			while(choix<1 || choix>7) {
				System.out.println("Joueur " + this.nom + " : Choisissez une branche parmi la liste suivante :\n1: RT\n2: ISI\n3: GM\n4: MTE\n5: GI\n6 : MM\n7 : A2I\n");
				choix = entreeClavier.nextInt();
			}
			Programmes[] listeProgrammes = Programmes.values();
			this.programme = listeProgrammes[choix-1];
			System.out.println("Vous avez choisi le programme " + this.programme);

			// Initialisation du solde de points
			this.soldePoints=400;

			// Initialisation de l'armee d'étudiants
			this.armeeEtudiants = new LinkedList<Combattant>();
			this.titulaires = new LinkedList<Combattant>();
			this.reservistes = new LinkedList<Combattant>();
			MaitreDuGobi mdg = new MaitreDuGobi(1,this.nom);
			armeeEtudiants.add(mdg);
			titulaires.add(mdg);

			for (int i=2;i<6;i++)
			{
				EtudiantDElite etuElite = new EtudiantDElite(i,this.nom);
				armeeEtudiants.add(etuElite);
				titulaires.add(etuElite);
			}

			for (int i=6;i<21;i++){
				Etudiant etu = new Etudiant(i,this.nom);
				armeeEtudiants.add(etu);
				titulaires.add(etu);
			}
		}
		
		public void genererArmee()
		{
			for (int i=1; i<16; i++)
			{
				int j=i;
				Combattant C = this.armeeEtudiants.stream().filter(c -> (c.id == j)).findFirst().orElse(null);
				C.constitution= (int) (Math.random() * 8) + 2;
				C.dexterite= (int) (Math.random() * 8) + 2;
				C.force= (int) (Math.random() * 8) + 2;
				C.resistance= (int) (Math.random() * 8) + 2;
				C.initiative= (int) (Math.random() * 8) + 2;
				C.reserviste=false;
			}
			
			for(int i=16;i<21;i++)
			{
				int j=i;
				Combattant C = this.armeeEtudiants.stream().filter(c -> (c.id == j)).findFirst().orElse(null);
				C.constitution= (int) (Math.random() * 8) + 2;
				C.dexterite= (int) (Math.random() * 8) + 2;
				C.force= (int) (Math.random() * 8) + 2;
				C.resistance= (int) (Math.random() * 8) + 2;
				C.initiative= (int) (Math.random() * 8) + 2;
				C.reserviste=true;
			}
			
			this.armeeEtudiantsToString();
		}

		
		// Getters et setters
		
		
		public String getNom() {
			return nom;
		}

		public void setNom(String nom) {
			this.nom = nom;
		}


		public int getSoldePoints() {
			return soldePoints;
		}

		public void setSoldePoints(int soldePoints) {
			this.soldePoints = soldePoints;
		}
		
		public int getReservistesLength()
		{
			return this.reservistes.size();
		}
		
		public int getTitulairesLength()
		{
			return this.titulaires.size();
		}
		
		public int getId()
		{
			return this.id;
		}
		
		
		// Afficher l'armee d'étudiats d'un élève
		
		public void armeeEtudiantsToString()
		{
			System.out.println("\n***** Armee d etudiants du joueur " + this.nom + "*****\n");
			Iterator <Combattant> i = this.armeeEtudiants.iterator();
			while(i.hasNext())
			{
				Combattant j = i.next();
				System.out.println("ID :" +j.id +" | Constitution : " +j.constitution +" | Force :" +j.force+ " | Resistance : " + j.resistance + " | Initiative : " +j.initiative + " | Dexterite" + j.dexterite + " | Reserviste : " +j.reserviste);
			} 
		}
		
		public void titulairesToString()
		{
			
			System.out.println("\n***** Titulaires *****\n");
			System.out.println(this.titulaires.size());
			Iterator <Combattant> i = this.titulaires.iterator();
			while(i.hasNext())
			{
				Combattant j = i.next();
				System.out.println("ID :" +j.id +" | Constitution : " +j.constitution +" | Force :" +j.force+ " | Resistance : " + j.resistance + " | Initiative : " +j.initiative + " | Dexterite" + j.dexterite + " | Reserviste : " +j.reserviste);
			} 
		}
		
		
		
		
		
		public void reservistesToString()
		{
			System.out.println("\n***** Reservistes *****\n");
			Iterator <Combattant> i = this.reservistes.iterator();
			while(i.hasNext())
			{
				Combattant j = i.next();
				System.out.println("ID :" +j.id +" | Constitution : " +j.constitution +" | Force :" +j.force+ " | Resistance : " + j.resistance + " | Initiative : " +j.initiative + " | Dexterite" + j.dexterite + " | Reserviste : " +j.reserviste);
			} 
		}
		
		
		
		
		
		
		
		public void combattantModifierPoints()
		{
			
			// Combattant comb_modif=this.armeeEtudiants.stream().filter(c -> (c.id == comb_id)).findFirst().orElse(null);

						//System.out.println("---\nTous les combattants");
						//this.armeeEtudiants.stream().forEach(c->System.out.println("\t->Combattant "+Integer.toString(c.id)));
						//System.out.println("---\nCombattants d'ID pair");
						//LinkedList<Combattant> toto = new LinkedList<Combattant>(this.armeeEtudiants.stream().filter(c -> (c.id % 2 == 1)).collect(Collectors.toList()));
						//toto.stream().forEach(c->System.out.println("\t->Combattant "+Integer.toString(c.id)));
						//System.out.println("---\nent");	
			
			this.armeeEtudiantsToString();

			Combattant comb_modif = this.findCombattant();

			Scanner clavier = new Scanner (System.in);
			System.out.println("Saisissez la catégorie de points a modifier :\n1:Consitution\n2:Force\n3:Initiative\n4: Dexterite\n5: Resistance");
			int categorie = clavier.nextInt();

			System.out.println("Saisissez le nombre de points a ajouter ou retirer :");
			int nb_points = clavier.nextInt();			

			if(comb_modif != null)
			{

				switch(categorie)
				{
				case 1:
					comb_modif.setConstitution(comb_modif.constitution+nb_points);
					this.soldePoints-=nb_points;
					break;
				case 2:
					comb_modif.setForce(comb_modif.force+nb_points);
					this.soldePoints-=nb_points;
					break;
				case 3:
					comb_modif.setInitiative(comb_modif.initiative+nb_points);
					this.soldePoints-=nb_points;
					break;
				case 4:
					comb_modif.setDexterite(comb_modif.dexterite+nb_points);
					this.soldePoints-=nb_points;
					break;
				case 5:
					comb_modif.setResistance(comb_modif.resistance+nb_points);
					this.soldePoints-=nb_points;
					break;
				default:
					break;
				}

			}
			else
			{
				System.out.println("Le combattant ou la catégorie n'existe(nt) pas");
			}

			this.armeeEtudiantsToString();
						
		}
		
		
		
		
		
		
		
		
		
		public void combattantModifierStrategie(){
			
			Combattant c = this.findCombattant();
			Scanner clavier = new Scanner(System.in);
			
			
			System.out.println("Saisissez le type de strategie : \n1: Offensive\n2: Defensive\n3: Aleatoire");
			int no_strategie = clavier.nextInt();
						
			
			switch(no_strategie)
			{
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			default:
				System.out.println("Le type de strategie saisi n'existe pas");
				break;
			}
		}
		
		
		
		
		
		
		
		
		public void combattantMettreEnReserve() {
			
			Combattant comb_reserve = this.findCombattant();
			comb_reserve.setReserviste(true);
			
			if(this.titulaires.contains(comb_reserve))
			{
				this.titulaires = this.titulaires.stream().filter(c -> c.reserviste == false).collect(Collectors.toList());
				this.titulairesToString();
				this.reservistes.add(comb_reserve);
			}
			
			this.armeeEtudiantsToString();
			
			this.reservistesToString();
			
		}
		
		
		
		
		
		
		
		public void combattantSortirReserve() {
			
			Combattant comb_reserve = this.findCombattant();
			comb_reserve.setReserviste(false);
			
			if(this.reservistes.contains(comb_reserve))
			{
				this.reservistes = this.reservistes.stream().filter(c -> c.reserviste == true).collect(Collectors.toList());
				this.reservistesToString();
				this.titulaires.add(comb_reserve);
			}
			
			this.armeeEtudiantsToString();
			
			this.titulairesToString();
		}
		
		
		
		
		
		
		
		
		
		public Combattant findCombattant()
		{
			Scanner clavier = new Scanner(System.in);
			System.out.println("Saisissez l'ID du combattant que vous voulez sortir de la reserve \n1: Maitre du gobi\n2-5: Etudiants d Elite\n6-20: Etudiants");
			int comb_id = clavier.nextInt();
			
			Combattant C =this.armeeEtudiants.stream().filter(c -> (c.id == comb_id)).findFirst().orElse(null);
			return C;
		}
		
		public Combattant findCombattantById(int comb_id)
		{
			Combattant C =this.armeeEtudiants.stream().filter(c -> (c.id == comb_id)).findFirst().orElse(null);
			return C;
		}
		
		
		
		public Combattant titulaireFindById()
		{
			Scanner clavier = new Scanner(System.in);
			System.out.println("Saisissez l'ID du combattant que vous voulez sortir de la reserve \n1: Maitre du gobi\n2-5: Etudiants d Elite\n6-20: Etudiants");
			int comb_id = clavier.nextInt();
			
			Combattant C =this.titulaires.stream().filter(c -> (c.id == comb_id)).findFirst().orElse(null);
			return C;
		}
		
		public Combattant titulaireFindById(int x)
		{	
			Combattant C =this.titulaires.stream().filter(c -> (c.id == x)).findFirst().orElse(null);
			return C;
		}
		
		public void deployerCombattant()
		{
			
			
		}
		
		
		
		
		
		
		
		public void retirerCombattant()
		{
			
		}
		
		

		
}
