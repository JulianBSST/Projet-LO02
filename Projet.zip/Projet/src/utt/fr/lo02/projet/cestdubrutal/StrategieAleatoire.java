package utt.fr.lo02.projet.cestdubrutal;

public class StrategieAleatoire implements Strategie{

	@Override
	public void jouer() {
			
	}

}
