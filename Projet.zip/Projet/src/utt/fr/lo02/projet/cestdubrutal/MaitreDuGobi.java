package utt.fr.lo02.projet.cestdubrutal;

public class MaitreDuGobi extends Combattant{
	public MaitreDuGobi(int id, String joueurPropriétaire) {
		this.creditsECTS = 30;
		this.dexterite = 2;
		this.force = 2;
		this.resistance = 2;
		this.constitution = 10;
		this.initiative = 2;
		Strategie strategie = new StrategieAleatoire();
		this.strategie = strategie;
		this.id = id;
		this.joueurPropriétaire = joueurPropriétaire;
		this.role = "MaitreDuGobi";
		this.reserviste = false;
		this.deploiement = false;
	}

	public boolean combattantVerifierIntegrite() {
		if (force>=2 & force <=10 & dexterite>=2 & dexterite<=10 & resistance>=2 & resistance<=10 & constitution>=10 & constitution<=30 & initiative>=2 & initiative<=10) {
			return true;
		}
		else {
			return false;
		}

	}
}
