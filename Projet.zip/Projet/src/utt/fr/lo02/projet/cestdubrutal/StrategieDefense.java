package utt.fr.lo02.projet.cestdubrutal;

public class StrategieDefense implements Strategie{

	@Override
	public void jouer() {
		
	}

}
