package utt.fr.lo02.projet.cestdubrutal;

public class StrategieAttaque implements Strategie{

	@Override
	public void jouer() {
		
	}

}
