package utt.fr.lo02.projet.cestdubrutal;

public class Combattant {
	protected int creditsECTS;
	protected int dexterite;
	protected int force;
	protected int resistance;
	protected int constitution;
	protected int initiative;
	protected Strategie strategie;
	protected boolean reserviste;
	protected String joueurPropriétaire;
	protected int id;
	protected String role;
	protected boolean deploiement;

	public Combattant() {

	}

	public boolean isReserviste() {
		return reserviste;
	}

	public void setReserviste(boolean reserviste) {
		this.reserviste = reserviste;
	}

	public int getCreditsECTS() {
		return creditsECTS;
	}

	public void setCreditsECTS(int creditsECTS) {
		this.creditsECTS = creditsECTS;
	}

	public int getDexterite() {
		return dexterite;
	}

	public void setDexterite(int dexterite) {
		this.dexterite = dexterite;
	}

	public int getForce() {
		return force;
	}

	public void setForce(int force) {
		this.force = force;
	}

	public int getResistance() {
		return resistance;
	}

	public void setResistance(int resistance) {
		this.resistance = resistance;
	}

	public int getConstitution() {
		return constitution;
	}

	public void setConstitution(int constitution) {
		this.constitution = constitution;
	}

	public int getInitiative() {
		return initiative;
	}

	public void setInitiative(int initiative) {
		this.initiative = initiative;
	}

	public String getJoueurPropriétaire() {
		return joueurPropriétaire;
	}

	public void setJoueurPropriétaire(String joueurPropriétaire) {
		this.joueurPropriétaire = joueurPropriétaire;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isDeploiement() {
		return deploiement;
	}

	public void setDeploiement(boolean deploiement) {
		this.deploiement = deploiement;
	}
}
