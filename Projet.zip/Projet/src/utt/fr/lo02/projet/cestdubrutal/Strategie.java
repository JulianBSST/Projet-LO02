package utt.fr.lo02.projet.cestdubrutal;

public interface Strategie {
	
	public void jouer();
}
