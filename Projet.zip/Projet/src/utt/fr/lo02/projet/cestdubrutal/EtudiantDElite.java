package utt.fr.lo02.projet.cestdubrutal;

public class EtudiantDElite extends Combattant {
	public EtudiantDElite(int id, String joueurPropriétaire) {
		this.creditsECTS = 30;
		this.dexterite = 1;
		this.force = 1;
		this.resistance = 1;
		this.constitution = 5;
		this.initiative = 1;
		Strategie strategie = new StrategieAleatoire();
		this.strategie = strategie;
		this.id = id;
		this.joueurPropriétaire = joueurPropriétaire;
		this.role = "EtudiantDElite";
		this.reserviste = false;
		this.deploiement = false;
	}

	public boolean combattantVerifierIntegrite() {
		if (force>=1 & force <=10 & dexterite>=1 & dexterite<=10 & resistance>=1 & resistance<=10 & constitution>=5 & constitution<=30 & initiative>=1 & initiative<=10) {
			return true;
		}
		else {
			return false;
		}

	}
}
