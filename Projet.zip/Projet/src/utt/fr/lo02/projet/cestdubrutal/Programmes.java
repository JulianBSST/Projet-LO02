package utt.fr.lo02.projet.cestdubrutal;

public enum Programmes {
	RT,ISI,GM,MTE,GI,MM,A2I;
}